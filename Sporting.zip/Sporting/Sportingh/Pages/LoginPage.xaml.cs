﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sportingh.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        private int failedLoginAttempts = 0;
        private string captchaCode;
        private readonly Random random = new Random();
        public LoginPage()
        {
            InitializeComponent();
        }

        private void GenerateCaptcha()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            captchaCode = new string(Enumerable.Repeat(chars, 4)
                .Select(s => s[random.Next(s.Length)]).ToArray());

            DrawCaptcha();
        }

        private void DrawCaptcha()
        {
            CaptchaCanvas.Children.Clear(); // Очистить предыдущие символы

            for (int i = 0; i < captchaCode.Length; i++)
            {
                // Создаем текстовый блок для каждого символа
                TextBlock textBlock = new TextBlock
                {
                    Text = captchaCode[i].ToString(),
                    FontSize = 30,
                    Foreground = new SolidColorBrush(Colors.Black),
                    RenderTransform = new TranslateTransform(random.Next(-10, 10), random.Next(-10, 10))
                };

                // Добавляем текстовый блок в Canvas
                Canvas.SetLeft(textBlock, i * 40); // Располагаем символы по горизонтали
                CaptchaCanvas.Children.Add(textBlock);

                // Перечеркивание символа
                if (random.Next(2) == 0) // 50% шанс на перечеркивание
                {
                    Line line = new Line
                    {
                        X1 = i * 40,
                        Y1 = 10,
                        X2 = (i * 40) + 30,
                        Y2 = 30,
                        Stroke = Brushes.Red,
                        StrokeThickness = 2,
                        RenderTransform = new TranslateTransform(random.Next(-5, 5), random.Next(-5, 5))
                    };
                    CaptchaCanvas.Children.Add(line);
                }
            }
        }


        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (failedLoginAttempts >= 1 && !ValidateCaptcha())
            {
                MessageBox.Show("Введите правильный CAPTCHA!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);

                // Блокируем кнопку на 10 секунд после неуспешной попытки с неправильной CAPTCHA
                BlockLoginButton();
                return;
            }
            try
            {
                StringBuilder errors = new StringBuilder();
                if (string.IsNullOrEmpty(LoginTextBox.Text))
                {
                    errors.AppendLine("Заполните логин!");
                }

                if (string.IsNullOrEmpty(PasswordBox.Password))
                {
                    errors.AppendLine("Заполните пароль!");
                }

                if (errors.Length > 0)
                {
                    MessageBox.Show(errors.ToString(), "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (Data.SportingGoodsDBEntities.GetContext().User
                    .Any(d => d.Login == LoginTextBox.Text &&
                    d.Password == PasswordBox.Password))
                {
                    // Успешный вход
                    var user = Data.SportingGoodsDBEntities.GetContext().User
                        .FirstOrDefault(d => d.Login == LoginTextBox.Text && d.Password == PasswordBox.Password);

                    // Навигация в зависимости от роли
                    Classes.Manager.MainFrame.Navigate(new Pages.ViewFitnessPage());
                    MessageBox.Show("Успех!", "Успех!", MessageBoxButton.OK, MessageBoxImage.Information);
                    failedLoginAttempts = 0; // Сбросить счетчик на успешном входе
                    HideCaptcha(); // Скрыть CAPTCHA при успешном входе

                    switch (user.Role.RoleName)
                    {
                        case "Администратор":
                            Classes.Manager.MainFrame.Navigate(new Pages.AdminLKPage());
                            break;

                        case "Клиент":
                            Classes.Manager.MainFrame.Navigate(new Pages.ViewFitnessPage());
                            break;

                        case "Менеджер":
                            Classes.Manager.MainFrame.Navigate(new Pages.ViewFitnessPage());
                            break;
                    }

                }
                else
                {
                    failedLoginAttempts++;
                    MessageBox.Show("Некорректный логин/пароль!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);

                    if (failedLoginAttempts == 1)
                    {
                        MessageBox.Show("Неуспешная авторизация. Пожалуйста, введите CAPTCHA.", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Warning);
                        ShowCaptcha(); // Показать CAPTCHA после первой неудачи
                    }

                    if (failedLoginAttempts >= 3)
                    {
                        BlockLoginButton(); // Блокировка кнопки после 3 неудачных попыток
                    }

                    GenerateCaptcha(); // Обновить CAPTCHA после неудачной попытки
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BlockLoginButton()
        {
            LoginButton.IsEnabled = false;
            System.Threading.Tasks.Task.Delay(10000).ContinueWith(t => Dispatcher.Invoke(() => LoginButton.IsEnabled = true));
        }

        private bool ValidateCaptcha()
        {
            return CaptchaInputTextBox.Text.Equals(captchaCode, StringComparison.OrdinalIgnoreCase);
        }

        private void ShowCaptcha()
        {
            CaptchaCanvas.Visibility = Visibility.Visible;
            CaptchaInputTextBox.Visibility = Visibility.Visible;
            RefreshCaptchaButton.Visibility = Visibility.Visible;
            GenerateCaptcha(); // Генерировать новую CAPTCHA
        }

        private void HideCaptcha()
        {
            CaptchaCanvas.Visibility = Visibility.Collapsed;
            CaptchaInputTextBox.Visibility = Visibility.Collapsed;
            RefreshCaptchaButton.Visibility = Visibility.Collapsed;
            CaptchaInputTextBox.Clear(); // Очистить ввод CAPTCHA
        }

        private void RefreshCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            Classes.Manager.MainFrame.Navigate (new Pages.ViewFitnessPage());
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            Classes.Manager.MainFrame.Navigate(new Pages.RegisterPage());
        }
    }
}
