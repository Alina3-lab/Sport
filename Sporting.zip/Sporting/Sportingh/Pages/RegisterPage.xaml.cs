﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sportingh.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
            Init();
        }
        private void Init()
        {
            var RoleList = Data.SportingGoodsDBEntities.GetContext().Role.ToList();
            RoleList.Insert(0, new Data.Role() { RoleName = "Выберите роль" });
            RoleTB.ItemsSource = RoleList;
            RoleTB.SelectedIndex = 0;
        }

        private void RegButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                // Проверки на пустые поля
                if (string.IsNullOrEmpty(LoginTB.Text))
                {
                    sb.AppendLine("Поле Логин пустое!");
                }
                if (string.IsNullOrEmpty(PasswordPB.Password))
                {
                    sb.AppendLine("Поле Пароль пустое!");
                }
                if (string.IsNullOrEmpty(SurnameTB.Text))
                {
                    sb.AppendLine("Поле Фамилия пустое!");
                }
                if (string.IsNullOrEmpty(NameTB.Text))
                {
                    sb.AppendLine("Поле Имя пустое!");
                }
                if (string.IsNullOrEmpty(PatronymicTB.Text))
                {
                    sb.AppendLine("Поле Отчество пустое!");
                }
                if (RoleTB.SelectedIndex == 0)
                {
                    sb.AppendLine("Выберите роль!");
                }

                // Проверка на null для выбранной роли
                var selectedRole = RoleTB.SelectedItem as Data.Role;
                if (selectedRole == null || selectedRole.RoleId <= 0)
                {
                    sb.AppendLine("Выберите корректную роль!");
                }

                if (sb.Length > 0)
                {
                    MessageBox.Show(sb.ToString(), "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Создание нового пользователя
                var newUser = new Data.User()
                {
                    Lname = SurnameTB.Text,
                    Surname = NameTB.Text,
                    Patronymic = PatronymicTB.Text,
                    Login = LoginTB.Text,
                    Password = PasswordPB.Password,
                    IdRole = selectedRole.RoleId // Используем RoleId выбранной роли напрямую
                };

                // Сохранение в базе данных
                using (var context = Data.SportingGoodsDBEntities.GetContext())
                {
                    context.User.Add(newUser);
                    context.SaveChanges();
                }

                MessageBox.Show("Успешная регистрация!", "Успех!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (DbEntityValidationException vex)
            {
                var errors = vex.EntityValidationErrors.SelectMany(x => x.ValidationErrors)
                                .Select(x => x.ErrorMessage);
                MessageBox.Show(string.Join(Environment.NewLine, errors), "Ошибка валидации!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Classes.Manager.MainFrame.Navigate(new Pages.LoginPage());
        }
    }
}
