﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sportingh.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListEventPage.xaml
    /// </summary>
    public partial class ListEventPage : Page
    {
        public ListEventPage()
        {
            InitializeComponent();
            ListEventFitness.ItemsSource = Data.SportingGoodsDBEntities.GetContext().ListEvent.ToList();
            Init();
        }
        public void Init()
        {
            if (Classes.Manager.CurrentUser != null)
            {
                FIOLabel.Visibility = Visibility.Visible;
                FIOLabel.Content = $"{Classes.Manager.CurrentUser.Surname}" +
                    $"{Classes.Manager.CurrentUser.Lname}" +
                    $"{Classes.Manager.CurrentUser.Patronymic}";

            }
            else
            {
                FIOLabel.Visibility = Visibility.Hidden;
            }
        }
        
        public List<Data.ListEvent> _currentProduct = Data.SportingGoodsDBEntities.GetContext().ListEvent.ToList();
        public void Update()
        {
            try
            {
                _currentProduct = Data.SportingGoodsDBEntities.GetContext().ListEvent.ToList();

                _currentProduct = (from item in Data.SportingGoodsDBEntities.GetContext().ListEvent
                                   where item.EventName.ToLower().Contains(SearchTextBox.Text) ||
                                   item.Description.ToLower().Contains(SearchTextBox.Text) ||
                                   item.Organization.ToLower().Contains(SearchTextBox.Text) ||
                                   item.Location.ToString().ToLower().Contains(SearchTextBox.Text) ||
                                   item.EventDate.ToString().ToLower().Contains(SearchTextBox.Text) ||
                                   item.ParticipantCount.ToString().ToLower().Contains(SearchTextBox.Text)
                                   select item).ToList();
                if (SortUpRadioButton.IsChecked == true)
                {
                    _currentProduct = _currentProduct.OrderBy(d => d.ParticipantCount).ToList();
                }
                if (SortDownRadioButton.IsChecked == true)
                {
                    _currentProduct = _currentProduct.OrderByDescending(d => d.ParticipantCount).ToList();
                }

                ListEventFitness.ItemsSource = _currentProduct;
            }
            catch (Exception)
            {

            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Classes.Manager.MainFrame.Navigate(new Pages.AdminLKPage());
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void SortUpRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            Update();
        }

        private void SortDownRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            Update();
        }
    }
}
